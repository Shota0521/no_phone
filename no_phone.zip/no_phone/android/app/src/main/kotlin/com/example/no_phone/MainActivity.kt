package com.example.no_phone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
